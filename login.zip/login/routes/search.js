const express = require('express');
const routers = express.Router();
const passport = require('passport');
const address = require('address'); 
const phone = require('phone');
const crypto = require('crypto');
const async = require('async');
const title = require('title');
const local = require('local');
const nodemailer = require('nodemailer');

//***********************
const Product = require('../models/productmodel');


// Checks if user is authenticated
function isAuthenticatedUser(req, res, next) {
    if(req.isAuthenticated()) {
        return next();
    }
    req.flash('error_msg', 'Please Login first to access this page.')
    res.redirect('/login');
}


routers.get('/search', (req, res) =>{
    res.render('search');
})

routers.post('/search',  (req, res)=> {
    if(!req.body.title) {
        req.flash('error_msg', "cannot null, Type again!");
        return res.redirect('/homepage');
    }

    const pro = Product.findOne({title : '/'+req.body.title+'/'})
    res.send({pro})
});

module.exports = routers;