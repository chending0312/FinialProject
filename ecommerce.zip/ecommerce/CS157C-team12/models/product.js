//Connecting MongoDB to JS
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ProductSchema = new Schema({
    title: String,
    price: Number,
    asin: String,
    image: String,
    category: [String],
    rating: {
        totalRatings: String,
        score: String
    },
    specifications: [String],
    productDetails: {
        firstAvailable: String,
        weight: String,
        brand: String
    }
})

module.exports = mongoose.model('Product', ProductSchema);

/*
//Connecting Mongo to JS
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ProductSchema = new Schema({
    name: String,
    category: [String],
    price: Number,
    ratings: {
        totalRatings: Number,
        overallRating: Number
    },
    reviews: [
        {
            userName: String,
            review: String
        }
    ],
    description: String,
    photo: String,
    productDetails: {
        manufacturer: String,
        itemWeight: String,
        brand: String,
        dateAvailable: String,
        productDimensions: {
            width: Number,
            height: Number
        },
        material: [String],
        ingredients: [String]
    }
});

module.exports = mongoose.model('Product', ProductSchema);
*/
