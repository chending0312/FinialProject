const express = require('express');
const app = express();
const path = require('path');
const Product = require('./models/product');
const ejsMate = require('ejs-mate');

//Connecting Mongo to JS
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/ecommerce', {
    useNewUrlParser: true,
    useCreateIndex: true,
    useUnifiedTopology: true
});

//Connecting to the database
const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error: "));
db.once("open", () => {
    console.log("Database connected");
});

app.engine('ejs', ejsMate);
app.set('view engine', 'ejs');
//Taking current directory name and joining the path + /views
app.set('views', path.join(__dirname, '/views'));

app.use(express.urlencoded({ extended: true }));


//Taking current directory name and joining the path + /public
//Public directory contains static files (css, js, images)
app.use(express.static(__dirname + '/public'));

app.get('/', (req, res) => {
    res.render('home.ejs');
})

//Showpage for all products
app.get('/products', async (req, res) => {
    const products = await Product.find({});

    res.render('productIndex', { products });
})

//Showpage for specific products based off _id
app.get('/products/:id', async (req, res) => {
    const products = await Product.findById(req.params.id);

    console.log(req.params);
    res.render('showProducts', { products });
    //res.render('tester', { products });
})

app.listen(3000, () => {
    console.log("Listening on port 3000");
})
