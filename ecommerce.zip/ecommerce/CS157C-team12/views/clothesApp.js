const asinIDS = ['B08M96YZN1', 'B08H43738R', 'B00EMAM9BC', 'B00JPLMD00']
const asinID = "B073JYC4XM"

// set up the request parameters
for (let i = 0; i < 3; i++) {
    const params = {
        api_key: "3E1E04C706664B36BFE1D51A94CAA873",
        type: "product",
        amazon_domain: "amazon.com",
        asin: `${asinIDS[i]}`
    }

    // make the http GET request to Rainforest API
    axios.get('https://api.rainforestapi.com/request', { params })
        .then(response => {

            // print the JSON response from Rainforest API
            console.log(JSON.stringify(response.data, 0, 2));
            console.log(response.data.product.title);

        }).catch(error => {
            // catch and print the error
            console.log(error);
        })
}