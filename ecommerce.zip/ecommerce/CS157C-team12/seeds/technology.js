module.exports = [
    'B08X6FLMR2', //1
    'B089TQWJKK', //2
    'B08CXRBL92', //3
    'B08KHD15B2', //4
    'B07YTHD64R', //5
    'B08RNWBHGW', //6
    'B077578W38', //7
    'B08NWBY8YJ', //8
    'B07ZPC9QD4', //9
    'B01M0GB8CC', //10
    'B0887GP791', //11
    'B07S76WBGF', //12
    'B08KGZ79N6', //13
    'B086383HC7', //14
    'B0817H41YN', //15
    'B0885N17CC', //16
    'B08P4Q91ZP', //17
    'B08P8PKGKZ', //18
    'B089DQ276V', //19
    'B08B3KKV67' //20

]