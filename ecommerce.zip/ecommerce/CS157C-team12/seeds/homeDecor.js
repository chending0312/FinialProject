module.exports = [
    'B07B3YDLK2', //1
    'B08DD2F7SX', //2
    'B08CVBT4JS', //3
    'B08XLQKCXX', //4
    'B08CVSRW3S', //5
    'B08KYKXP9Z', //6
    'B081TSCS8Y', //7
    'B08YRVCJ19', //8
    'B08D119FPM', //9
    'B07ZRG5DYK', //10
    'B07ZRG5DYK', //11
    'B08JM7M8W9', //12
    'B088S9VJ6Y', //13
    'B08PDVZFJN', //14
    'B08M3BM4CY', //15
    'B08TV1W52P', //16
    'B07CWMN9KP', //17
    'B07H25C98F', //18
    'B091SHX8N5', //19
    'B07GWNB3NP' //20

]