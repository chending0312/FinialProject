module.exports = [
    'B08M96YZN1', //1
    'B08H43738R', //2
    'B00EMAM9BC', //3
    'B00JPLMD00', //4
    'B001DPMETG', //5
    'B07WWC3T9Q', //6
    'B00NR1YIKM', //7
    'B0009RFB76', //8
    'B074PVTPBW', //9
    'B07XQBY5QQ', //10
    'B01N1LL62W', //11
    'B00949CTQQ', //12
    'B00NR1YQHM', //13
    'B00MEDOY2G', //14
    'B00AREGVUM', //15
    'B07CTSS14R', //16
    'B01NCM25K7', //17
    'B007DGRT3K', //18
    'B01LSUQSB0', //19
    'B08PN4V3YC' //20

]