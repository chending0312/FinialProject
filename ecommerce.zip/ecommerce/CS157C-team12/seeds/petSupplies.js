module.exports = [
    'B06Y5TR3S5', //1
    'B08S9NCGHV', //2
    'B08GKBWFGZ', //3
    'B088YHKDCT', //4
    'B07N316V8C', //5
    'B088JPC99D', //6
    'B08CVQ6NCJ', //7
    'B07DLXF7XL', //8
    'B08CCGNBVY', //9
    'B01LWS9514', //10
    'B07CSG684C', //11
    'B07G2STJHN', //12
    'B08NBC2RF5', //13
    'B01KG9WMWI', //14
    'B087YSQLFK', //15
    'B08LKFHX17', //16
    'B01EX0H12M', //17
    'B004AWH6ZG', //18
    'B01LNB6SA0', //19
    'B07D9X3642' //20

]