module.exports = [
    'B07P6MV2CZ', //1
    'B07L6B6LML', //2
    'B074PVVPNH', //3
    'B01N758KMB', //4
    'B08VFFSN8X', //5
    'B07R5VXL2D', //6
    'B08FW5GRDP', //7
    'B08S6F8C21', //8
    'B091G3GLLW', //9
    'B091BVYF6J', //10
    'B07BPCYZTS', //11
    'B08JHRMHQS', //12
    'B092CX5KMJ', //13
    'B07Y1GBGXH', //14
    'B08M7CGGZB', //15
    'B08ZM7HQ2N', //16
    'B07M61KJP5', //17
    'B071JDWV4R', //18
    'B08QZVJVR2', //19
    'B08P6B39YR' //20

]