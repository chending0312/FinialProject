var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var CartSchema = new Schema({
   owner: { type: Schema.Types.ObjectId, ref: 'User'},
   total: { type: Number,default: 0},
   item: [{
       item: {type: Schema.types.ObjectId, ref: 'profuct'},
       quantity: { type: Number, default: 1},
       price: {type: Number,default: 0},
   }]

});

module.exports = mongoose.model('cart',CartSchema);