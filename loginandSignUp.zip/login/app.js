const express = require('express');
const app = express();
app.use(express.json())
//improt all the package
const path = require('path');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const flash = require('connect-flash');
const session = require('express-session');
const passport = require('passport');
const address = require('address'); 
const phone = require('phone');
const LocalStrategy = require('passport-local').Strategy;
const request = require('request');
const Category = require('./models/category');
//const cartLength = require('./middlewares/middlewares');

//***************
// const order = require('ordermodel'); 
//****************** 
// const product = require('productmodel');


//Requiring user route
const userRoutes = require('./routes/users');


//Requiring user model
const User = require('./models/usermodel');
const adminRoutes = require('./routes/admin');
//product model*************
const Product = require('./models/productmodel');
//order model**************
const Order = require('./models/ordermodel');

const apiRoutes = require('./API/api');


//app.use(cartLength);

dotenv.config({path : './config.env'});

//connect to mongoDB
mongoose.connect(process.env.DATABASE_LOCAL, {
    useNewUrlParser : true,
    useUnifiedTopology : true,
    useCreateIndex : true
});

//middleware for session
app.use(session({
    secret : 'login/sign up application.',
    resave : true,
    saveUninitialized : true
}));

//middleware flash messages
app.use(flash());

//set middleware for category
app.use(function(req,res,next){
    Category.find({}, function(err,categories){
        if (err) return next(err);
        res.locals.categories = categories;
        next();
    });
});

app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy({usernameField : 'email'}, User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

//setting middlware globally
app.use((req, res, next)=> {
    res.locals.success_msg = req.flash(('success_msg'));
    res.locals.error_msg = req.flash(('error_msg'));
    res.locals.error = req.flash(('error'));
    res.locals.currentUser = req.user;
    res.locals.currentOrder = req.order;
    res.locals.currentProduct = req.product;
    next();
});

app.use(bodyParser.urlencoded({extended:true}));
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(express.static('public'));

app.use(userRoutes);
app.use(adminRoutes);
//app.use(apiRoutes);


app.listen(process.env.PORT, ()=> {
    console.log('Server is started');
});