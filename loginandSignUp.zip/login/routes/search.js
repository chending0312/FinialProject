const express = require('express');
const router = express.Router();
const passport = require('passport');
const crypto = require('crypto');
const async = require('async');
const nodemailer = require('nodemailer');

//Requiring user model
const User = require('../models/usermodel');
//***********************
const Order = require('../models/ordermodel');
const Product = require('../models/productmodel');


// Checks if user is authenticated
function isAuthenticatedUser(req, res, next) {
    if(req.isAuthenticated()) {
        return next();
    }
    req.flash('error_msg', 'Please Login first to access this page.')
    res.redirect('/login');
}

app.use((req, res, next)=> {
    res.locals.Product = req.Product;
    next();
});



router.get('/product',isAuthenticatedUser, (req, res) =>{
    res.render('product');
})

router.get('/search',isAuthenticatedUser, (req, res) =>{
    res.render('search');
})

router.get('/getfood',isAuthenticatedUser, (req, res) =>{
    res.render('getfood');
})

router.get('/getbook',isAuthenticatedUser, (req, res) =>{
    res.render('getbook');
})



router.post('/search', (req, res)=> {
    let {resget} = req.body;

    resget.findOne({
        resget: res.body.resget
    })
    if(!resget){
        return res.status(422).send({
            message:'product is not exist'
        })
    }
    res.send({
        resget
    })
})

router.post('/getfood', (req, res)=> {
    let {getfood} = req.body;

    resget.findOne({
        resget: res.body.getfood
    })
    if(!resget){
        return res.status(422).send({
            message:'product is not exist'
        })
    }
    res.send({
        resget
    })
})

router.post('/getbook', (req, res)=> {
    let {getbook} = req.body;

    resget.findOne({
        resget: res.body.getbook
    })
    if(!resget){
        return res.status(422).send({
            message:'product is not exist'
        })
    }
    res.send({ 
        getbook
    })
})