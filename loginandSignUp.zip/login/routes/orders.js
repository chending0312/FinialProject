const express = require('express');
const router = express.Router();
const passport = require('passport');
const crypto = require('crypto');
const async = require('async');
const nodemailer = require('nodemailer');

//Requiring user model
const User = require('../models/usermodel');
//***********************
const Order = require('../models/ordermodel');
const Product = require('../models/productmodel');


// Checks if user is authenticated
function isAuthenticatedUser(req, res, next) {
    if(req.isAuthenticated()) {
        return next();
    }
    req.flash('error_msg', 'Please Login first to access this page.')
    res.redirect('/login');
}

router.get('/orders', isAuthenticatedUser, (req, res) =>{
    res.render('orders');
})

// router.post('/orders', (req, res)=> {
//     let {Order} = req.body;

//     resget.findOne({
//         resget: res.body.Order
//     })
//     if(!resget){
//         return res.status(422).send({
//             message:'order is not exist'
//         })
//     }
//     res.send({ 
//         getbook
//     })
// })